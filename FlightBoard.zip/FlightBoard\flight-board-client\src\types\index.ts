export interface FlightDto {
  id: number;
  flightNumber: string;
  destination: string;
  gate: string;
  departureTime: string; // ISO datetime string
  status: 'Scheduled' | 'Boarding' | 'Departed' | 'Landed'; // can be extended as needed
}

export type FlightFormData = {
  flightNumber: string;
  destination: string;
  departureTime: string; 
  gate: string;
};