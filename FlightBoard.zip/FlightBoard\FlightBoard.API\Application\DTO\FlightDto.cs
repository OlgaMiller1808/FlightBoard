﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTO
{
    public class FlightDto
    {
        public int Id { get; set; }
        public string FlightNumber { get; set; } = default!;
        public string Destination { get; set; } = default!;
        public DateTime DepartureTime { get; set; }
        public string Gate { get; set; } = default!;
        public string? Status { get; set; } = default!;
    }
}
