﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application.DTO;
using Application.Interfaces;
using Application.Services;
using Domain.Entities;
using Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Infrastructure.Services
{
    public class FlightService : IFlightService
    {
        private readonly AppDbContext _context;
        private readonly IFlightStatusCalculator _statusCalculator;
        private readonly ILogger<FlightService> _logger;

        public FlightService(AppDbContext context, IFlightStatusCalculator statusCalculator, ILogger<FlightService> logger)
        {
            _context = context;
            _statusCalculator = statusCalculator;
            _logger = logger;
        }

        public async Task<IEnumerable<FlightDto>> GetAllFlightsAsync()
        {
            var now = DateTime.UtcNow;
            return await _context.Flights
                .Select(f => new FlightDto
                {
                    Id = f.Id,
                    FlightNumber = f.FlightNumber,
                    Destination = f.Destination,
                    DepartureTime = f.DepartureTime,
                    Gate = f.Gate,
                    Status = _statusCalculator.CalculateStatus(f.DepartureTime, now)
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<FlightDto>> SearchFlightsAsync(string? status, string? destination)
        {
            var now = DateTime.UtcNow;
            var query = _context.Flights.AsQueryable();

            if (!string.IsNullOrWhiteSpace(destination))
                query = query.Where(f => f.Destination.Contains(destination));

            var results = await query.ToListAsync();

            return results
                .Select(f => new FlightDto
                {
                    Id = f.Id,
                    FlightNumber = f.FlightNumber,
                    Destination = f.Destination,
                    DepartureTime = f.DepartureTime,
                    Gate = f.Gate,
                    Status = _statusCalculator.CalculateStatus(f.DepartureTime, now)
                })
                .Where(f => string.IsNullOrWhiteSpace(status) || f.Status.Equals(status, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        public async Task<FlightDto> AddFlightAsync(FlightDto dto)
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(dto.FlightNumber) ||
                string.IsNullOrWhiteSpace(dto.Destination) ||
                string.IsNullOrWhiteSpace(dto.Gate))
            {
                throw new ArgumentException("All fields are required.");
            }

            if (dto.DepartureTime <= DateTime.UtcNow)
            {
                throw new ArgumentException("Departure time must be in the future.");
            }

            // Ensure flight number is unique
            var exists = await _context.Flights
                .AnyAsync(f => f.FlightNumber == dto.FlightNumber);
            if (exists)
            {
                throw new ArgumentException("Flight number must be unique.");
            }

            var flight = new Flight
            {
                FlightNumber = dto.FlightNumber,
                Destination = dto.Destination,
                Gate = dto.Gate,
                DepartureTime = dto.DepartureTime
            };

            _context.Flights.Add(flight);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Flight added: {FlightNumber} to {Destination} at {DepartureTime}",
                dto.FlightNumber, dto.Destination, dto.DepartureTime);

            var now = DateTime.UtcNow;
            var result = new FlightDto
            {
                Id = flight.Id,
                FlightNumber = flight.FlightNumber,
                Destination = flight.Destination,
                Gate = flight.Gate,
                DepartureTime = flight.DepartureTime,
                Status = _statusCalculator.CalculateStatus(flight.DepartureTime, now)
            };

            return result;
        }

        public async Task DeleteFlightAsync(int id)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight == null) throw new Exception($"Flight with ID {id} not found.");

            _context.Flights.Remove(flight);
            await _context.SaveChangesAsync();

            _logger.LogWarning("Flight deleted: ID {Id}, FlightNumber: {FlightNumber}",
                flight.Id, flight.FlightNumber);
        }
    }
}
