﻿using FlightBoard.API.Hubs;
using Microsoft.AspNetCore.SignalR;
using Application.DTO;

namespace FlightBoard.API.Srvices
{
    public interface IFlightNotifier
    {
        Task NotifyFlightAdded(FlightDto flight);
        Task NotifyFlightDeleted(int id);
    }

    public class FlightNotifier : IFlightNotifier
    {
            private readonly IHubContext<FlightHub> _hubContext;

            public FlightNotifier(IHubContext<FlightHub> hubContext)
            {
                _hubContext = hubContext;
            }

            public Task NotifyFlightAdded(FlightDto flight)
            {
                return _hubContext.Clients.All.SendAsync("FlightAdded", flight);
            }

            public Task NotifyFlightDeleted(int id)
            {
                return _hubContext.Clients.All.SendAsync("FlightDeleted", id);
            }
        }
}
