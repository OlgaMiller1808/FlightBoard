﻿using Application.DTO;
using FluentValidation;

public class FlightDtoValidator : AbstractValidator<FlightDto>
{
    public FlightDtoValidator()
    {
        RuleFor(f => f.FlightNumber).NotEmpty().WithMessage("Flight Number is required.");
        RuleFor(f => f.Destination).NotEmpty();
        RuleFor(f => f.Gate).NotEmpty();
        RuleFor(f => f.DepartureTime).Must(dt => dt > DateTime.UtcNow).WithMessage("Departure time must be in the future.");
    }
}