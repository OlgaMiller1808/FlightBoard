import { API_BASE_URL } from './config';
import { FlightDto, FlightFormData } from '../types';

// Fetch all flights
export async function getFlights(): Promise<FlightDto[]> {
 const res = await fetch(`${API_BASE_URL}/flights`);
  if (!res.ok) throw new Error('Failed to fetch flights');
  return res.json();
}

// Add a new flight
export async function addFlight(data: FlightFormData): Promise<FlightDto> {
  const response = await fetch(`${API_BASE_URL}/flights`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Failed to add flight:', response.status, errorText);
    throw new Error('Failed to add flight');
  }

  return await response.json();
}

// Delete a flight by id
export async function deleteFlight(id: number): Promise<void> {
  const res = await fetch(`${API_BASE_URL}/flights/${id}`, {
    method: 'DELETE',
  });
  if (!res.ok) {
    const errText = await res.text();
    console.error('Delete error:', res.status, errText);
    throw new Error('Failed to delete flight');
  }
}

// Search flights by optional status and destination filters
export async function searchFlights(status?: string, destination?: string): Promise<FlightDto[]> {
  const query = new URLSearchParams();
  if (status) query.append('status', status);
  if (destination) query.append('destination', destination);

  const res = await fetch(`${API_BASE_URL}/flights/search?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to search flights');
  return res.json();
}
