﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application.DTO;

namespace Application.Interfaces
{
    public interface IFlightService
    {
        Task<IEnumerable<FlightDto>> GetAllFlightsAsync();
        Task<IEnumerable<FlightDto>> SearchFlightsAsync(string? status, string? destination);
        Task<FlightDto> AddFlightAsync(FlightDto dto);
        Task DeleteFlightAsync(int id);
    }
}
