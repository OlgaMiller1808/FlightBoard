import React from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import AddFlightForm from './features/flights/AddFlightForm';
import FlightTable from './features/flights/FlightTable';
import { useAddFlightMutation } from './api/useFlightQuery';
import FlightFilters from './features/flights/FlightFilters';
import './App.css';
import { SignalRListener } from './features/signalIr/SignalRListener';

const App: React.FC = () => {
  return (
    <>
     <SignalRListener />
    <div className="container">
      <h1>Flight Board</h1>

      <nav style={{ marginBottom: 20 }}>
        <Link to="/flights" style={{ marginRight: 20 }}>View Flights</Link>
        <Link to="/flights/add">+ Add Flight</Link>
      </nav>

      <Routes>
        <Route path="/" element={<FlightTable />} />
        <Route path="/flights" element={<FlightListPage />} />
        <Route path="/flights/add" element={<AddFlightPage />} />
      </Routes>
    </div>
   
    </>
  );
};

const FlightListPage: React.FC = () => {
  return (
    <>
      <FlightFilters />
      <FlightTable />
    </>
  );
};
const AddFlightPage: React.FC = () => {
  const navigate = useNavigate();
  const addFlightMutation = useAddFlightMutation();

  return (
    <AddFlightForm
      onAdd={async (data) => {
        await addFlightMutation.mutateAsync(data);
        navigate('/flights');
      }}
    />
  );
};


export default App;
