using Xunit;
using Moq;
using Infrastructure.Services;
using Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Application.DTO;

namespace FlightBoard.Application.Tests
{
    public class FlightServiceTests
    {
        private readonly AppDbContext _dbContext;
        private readonly FlightService _service;

        public FlightServiceTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _dbContext = new AppDbContext(options);
            _service = new FlightService(_dbContext);
        }

        #region Add Flight Tests
        [Fact]
        public async Task AddFlightAsync_Should_Add_Valid_Flight()
        {
            // Arrange
            var dto = new FlightDto
            {
                FlightNumber = "LY101",
                Destination = "Tel Aviv",
                Gate = "A1",
                DepartureTime = DateTime.UtcNow.AddHours(2)
            };

            // Act
            var result = await _service.AddFlightAsync(dto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(dto.FlightNumber, result.FlightNumber);
            Assert.Equal("Scheduled", result.Status);
        }

        [Fact]
        public async Task AddFlightAsync_Should_Throw_For_Duplicate_FlightNumber()
        {
            // Arrange
            var dto = new FlightDto
            {
                FlightNumber = "UA202",
                Destination = "New York",
                Gate = "B2",
                DepartureTime = DateTime.UtcNow.AddHours(3)
            };

            await _service.AddFlightAsync(dto); // Add once

            // Act + Assert
            var ex = await Assert.ThrowsAsync<ArgumentException>(() =>
                _service.AddFlightAsync(dto));

            Assert.Equal("Flight number must be unique.", ex.Message);
        }

        [Fact]
        public async Task AddFlightAsync_Should_Throw_For_Past_Departure()
        {
            var dto = new FlightDto
            {
                FlightNumber = "LH300",
                Destination = "Berlin",
                Gate = "C4",
                DepartureTime = DateTime.UtcNow.AddMinutes(-30)
            };

            var ex = await Assert.ThrowsAsync<ArgumentException>(() =>
                _service.AddFlightAsync(dto));

            Assert.Contains("future", ex.Message);
        }

        #endregion

        #region Delete Flight Tests
        [Fact]
        public async Task DeleteFlightAsync_Should_Remove_Existing_Flight()
        {
            // Arrange
            var dto = new FlightDto
            {
                FlightNumber = "AA400",
                Destination = "Dallas",
                Gate = "D5",
                DepartureTime = DateTime.UtcNow.AddHours(1)
            };
            var flight = await _service.AddFlightAsync(dto);
            Assert.NotNull(flight);
            // Act
            await _service.DeleteFlightAsync(flight.Id);
            // Assert
            var deletedFlight = await _dbContext.Flights.FindAsync(flight.Id);
            Assert.Null(deletedFlight);
        }
        [Fact]
        public async Task DeleteFlightAsync_Should_Throw_For_NonExistent_Flight()
        {
            // Act + Assert
            var ex = await Assert.ThrowsAsync<Exception>(() =>
                _service.DeleteFlightAsync(9999)); // Non-existent ID
            Assert.Contains("not found", ex.Message);
        }

        #endregion

        #region Search Flights Tests
        [Fact]
        public async Task SearchFlightsAsync_Should_Filter_By_Destination()
        {
            await SeedFlightsAsync();

            var results = await _service.SearchFlightsAsync(null, "New");

            Assert.Single(results);
            Assert.Contains("New York", results.First().Destination);
        }

        [Fact]
        public async Task SearchFlightsAsync_Should_Filter_By_Status()
        {
            await SeedFlightsAsync();

            var results = await _service.SearchFlightsAsync("Scheduled", null);

             //Assert.Equal("Departed", results.First().Status);
            Assert.NotEmpty(results);
        }

        [Fact]
        public async Task SearchFlightsAsync_Should_Filter_By_Status_And_Destination()
        {
            await SeedFlightsAsync();

            var results = await _service.SearchFlightsAsync("Scheduled", "Chicago");

            Assert.Single(results);
            Assert.Equal("CA300", results.First().FlightNumber);
        }

        private async Task SeedFlightsAsync()
        {
            var flights = new List<FlightDto>
            {
                new() { FlightNumber = "AA100", Destination = "New York", DepartureTime = DateTime.UtcNow.AddHours(4), Gate = "A1" },
                new() { FlightNumber = "BA200", Destination = "London", DepartureTime = DateTime.UtcNow.AddHours(1), Gate = "B2" },
                new() { FlightNumber = "CA300", Destination = "Chicago", DepartureTime = DateTime.UtcNow.AddMinutes(130), Gate = "C3" }
            };

            foreach (var dto in flights)
                await _service.AddFlightAsync(dto);
        }
        #endregion
    }
}