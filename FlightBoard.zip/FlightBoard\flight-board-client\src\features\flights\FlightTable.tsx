import React, { useState } from 'react';
import { useFlightsQuery, useSearchFlightsQuery, useDeleteFlightMutation } from '../../api/useFlightQuery';
import { FlightDto } from '../../types';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { useQueryClient } from '@tanstack/react-query';

const FlightTable: React.FC = () => {
  const queryClient = useQueryClient();
  const { status, destination } = useSelector((state: RootState) => state.flightFilters);

  const allFlightsQuery = useFlightsQuery();
  const searchFlightsQuery = useSearchFlightsQuery(status, destination);

  // Use search query if filters applied, else all flights
  const query = status || destination ? searchFlightsQuery : allFlightsQuery;
  const { data: flights = [], isLoading, isError } = query;

  const deleteMutation = useDeleteFlightMutation();

  // Pending delete state
  const [pendingDelete, setPendingDelete] = useState<{
    flight: FlightDto;
    timeoutId: NodeJS.Timeout;
  } | null>(null);

  // Handle Delete with Undo
  const handleDelete = (flight: FlightDto) => {
    const confirmDelete = window.confirm('Delete this flight? You can undo within 5 seconds.');
    if (!confirmDelete) return;

    // Optimistically update cache (remove flight)
    queryClient.setQueryData<FlightDto[]>(['flights'], (oldFlights) =>
      oldFlights?.filter(f => f.id !== flight.id) ?? []
    );

    // Schedule backend delete after 5 seconds
    const timeoutId = setTimeout(() => {
      deleteMutation.mutate(flight.id);
      setPendingDelete(null);
    }, 5000);

    setPendingDelete({ flight, timeoutId });
  };

  // Undo delete action
  const undoDelete = () => {
    if (!pendingDelete) return;

    clearTimeout(pendingDelete.timeoutId);

    // Restore the flight in cache
    queryClient.setQueryData<FlightDto[]>(['flights'], (oldFlights) =>
      [...(oldFlights ?? []), pendingDelete.flight]
    );

    setPendingDelete(null);
  };

  if (isLoading) return <p>Loading flights...</p>;
  if (isError) return <p>Error loading flights.</p>;

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Flight Number</th>
            <th>Destination</th>
            <th>Departure Time</th>
            <th>Gate</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {flights.map((flight) => (
            <tr key={flight.id}>
              <td>{flight.flightNumber}</td>
              <td>{flight.destination}</td>
              <td>{new Date(flight.departureTime).toLocaleString()}</td>
              <td>{flight.gate}</td>
              <td>{flight.status}</td>
              <td>
                <button onClick={() => handleDelete(flight)}>🗑️ Delete flight</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Undo popup */}
      {pendingDelete && (
        <div style={{ marginTop: 20, background: '#fff3cd', padding: '10px', border: '1px solid #ffeeba', color: '#856404' }}>
          Deleted flight <strong>{pendingDelete.flight.flightNumber}</strong>.
          <button onClick={undoDelete} style={{ marginLeft: 10 }}>
            Undo
          </button>
        </div>
      )}
    </div>
  );
};

export default FlightTable;
