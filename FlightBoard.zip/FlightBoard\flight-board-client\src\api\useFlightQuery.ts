import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getFlights, addFlight, deleteFlight, searchFlights } from './flightsApi';
import { FlightDto, FlightFormData } from '../types';

export function useFlightsQuery() {
  return useQuery<FlightDto[], Error>({
    queryKey: ['flights'],
    queryFn: getFlights
  });
}

export function useAddFlightMutation() {
  const queryClient = useQueryClient();

  return useMutation<FlightDto, Error, FlightFormData>({
    mutationFn: addFlight,
    onSuccess: () =>{
        queryClient.invalidateQueries({queryKey: ['flights']});
    },
  });
}

export function useDeleteFlightMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteFlight,
    // Optimistic update:
    onMutate: async (flightId: number) => {
      await queryClient.cancelQueries({ queryKey: ['flights'] });

      const previousFlights = queryClient.getQueryData<FlightDto[]>(['flights']);

      queryClient.setQueryData<FlightDto[]>(['flights'], old =>
        old?.filter(f => f.id !== flightId)
      );

      return { previousFlights };
    },
    onError: (err, flightId, context) => {
      // Rollback on error
      if (context?.previousFlights) {
        queryClient.setQueryData(['flights'], context.previousFlights);
      }
      alert('Failed to delete flight');
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['flights'] });
    }
  });
}

export function useSearchFlightsQuery(status?: string, destination?: string) {
  return useQuery<FlightDto[]>({
    queryKey: ['flights', { status, destination }],
    queryFn: () => searchFlights(status, destination),
    enabled: !!status || !!destination,
  });
}
