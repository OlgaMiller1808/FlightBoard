﻿using Microsoft.AspNetCore.SignalR;


namespace FlightBoard.API.Hubs
{
    public class FlightHub : Hub
    {
    }
}
