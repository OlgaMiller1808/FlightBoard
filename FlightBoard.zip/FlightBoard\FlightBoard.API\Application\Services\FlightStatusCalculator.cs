﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class FlightStatusCalculator : IFlightStatusCalculator
    {
        public string CalculateStatus(DateTime departureTime, DateTime now)
        {
            var diffMinutes = (departureTime - now).TotalMinutes;

            if (diffMinutes > 30)
                return "Scheduled";
            else if (diffMinutes <= 30 && diffMinutes >= 0)
                return "Boarding";
            else if (diffMinutes < 0 && diffMinutes >= -60)
                return "Departed";
            else
                return "Landed";
        }
    }
}
