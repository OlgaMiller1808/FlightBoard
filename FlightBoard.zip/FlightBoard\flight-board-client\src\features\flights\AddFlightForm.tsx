import React, { useState } from 'react';
import { FlightFormData } from '../../types';

type Props = {
  onAdd: (data: FlightFormData) => Promise<void>;
  onCancel?: () => void;
};

const AddFlightForm: React.FC<Props> = ({ onAdd, onCancel }) => {
  const [formData, setFormData] = useState<FlightFormData>({
    flightNumber: '',
    destination: '',
    departureTime: '',
    gate: '',
  });

  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validate = () => {
    if (!formData.flightNumber || !formData.destination || !formData.gate || !formData.departureTime) {
      return 'All fields are required.';
    }

    const departureDate = new Date(formData.departureTime);
    if (departureDate <= new Date()) {
      return 'Departure time must be in the future.';
    }

    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setError('');
    await onAdd(formData);
    setFormData({ flightNumber: '', destination: '', departureTime: '', gate: '' });
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 20, border: '1px solid #ccc', padding: 20, borderRadius: 10 }}>
      <h2>Add Flight</h2>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div style={{ marginBottom: 10 }}>
        <label>Flight Number:</label><br />
        <input
          type="text"
          name="flightNumber"
          value={formData.flightNumber}
          onChange={handleChange}
          required
        />
      </div>

      <div style={{ marginBottom: 10 }}>
        <label>Destination:</label><br />
        <input
          type="text"
          name="destination"
          value={formData.destination}
          onChange={handleChange}
          required
        />
      </div>

      <div style={{ marginBottom: 10 }}>
        <label>Gate:</label><br />
        <input
          type="text"
          name="gate"
          value={formData.gate}
          onChange={handleChange}
          required
        />
      </div>

      <div style={{ marginBottom: 10 }}>
        <label>Departure Time:</label><br />
        <input
          type="datetime-local"
          name="departureTime"
          value={formData.departureTime}
          onChange={handleChange}
          required
        />
      </div>

      <button type="submit">Add Flight</button>
      {onCancel && (
        <button
          type="button"
          onClick={onCancel}
          style={{ marginLeft: 10 }}
        >
          Cancel
        </button>
      )}
    </form>
  );
};

export default AddFlightForm;
