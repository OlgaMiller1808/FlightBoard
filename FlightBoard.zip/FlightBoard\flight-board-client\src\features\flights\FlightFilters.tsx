import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setStatus, setDestination, clearFilters } from './flightFiltersSlice';
import { RootState } from '../../store';

const FlightFilters: React.FC = () => {
  const dispatch = useDispatch();
    const { status, destination } = useSelector((state: RootState) => state.flightFilters);

  return (
    <div style={{ marginBottom: '1rem' }}>
      <input
        placeholder="Destination"
        value={destination}
        onChange={(e) => dispatch(setDestination(e.target.value))}
        style={{ marginRight: 10 }}
      />
      <select
        value={status}
        onChange={(e) => dispatch(setStatus(e.target.value))}
        style={{ marginRight: 10 }}
      >
        <option value="">All Statuses</option>
        <option value="Scheduled">Scheduled</option>
        <option value="Boarding">Boarding</option>
        <option value="Departed">Departed</option>
        <option value="Landed">Landed</option>
      </select>
      <button onClick={() => dispatch(clearFilters())}>Clear</button>
    </div>
  );
};

export default FlightFilters;
