﻿using Application.DTO;
using Application.Interfaces;
using Domain.Entities;
using FlightBoard.API.Hubs;
using FlightBoard.API.Srvices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace FlightBoard.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FlightsController : ControllerBase
    {
        private readonly IFlightService _service;
        private readonly IFlightNotifier _notifier;
        private readonly IHubContext<FlightHub> _hubContext;    

        public FlightsController(IFlightService service, IFlightNotifier notifier, IHubContext<FlightHub> hubContext)
        {
            _service = service;
            _notifier = notifier;
            _hubContext = hubContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll() =>
            Ok(await _service.GetAllFlightsAsync());

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string? status, [FromQuery] string? destination)
        {
            var results = await _service.SearchFlightsAsync(status, destination);
            return Ok(results);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] FlightDto dto)
        {
            try
            {
                var result = await _service.AddFlightAsync(dto);
                await _notifier.NotifyFlightAdded(result);
                await _hubContext.Clients.All.SendAsync("FlightCreated", result);
                return CreatedAtAction(nameof(GetAll), new { id = result.Id }, result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _service.DeleteFlightAsync(id);
                await _hubContext.Clients.All.SendAsync("FlightDeleted", id);
                await _notifier.NotifyFlightDeleted(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
