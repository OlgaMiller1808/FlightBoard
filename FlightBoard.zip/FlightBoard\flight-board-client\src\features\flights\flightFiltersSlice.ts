import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface FlightFilter {
  destination: string;
  status: string;
}

const initialState: FlightFilter = {
  destination: '',
  status: ''
};

const flightFiltersSlice = createSlice({
  name: 'flightFilters',
  initialState,
  reducers: {
    setDestination: (state, action: PayloadAction<string>) => {
      state.destination = action.payload;
    },
    setStatus: (state, action: PayloadAction<string>) => {
      state.status = action.payload;
    },
    clearFilters: () => initialState,
  },
});

export const { setDestination, setStatus, clearFilters } = flightFiltersSlice.actions;
export default flightFiltersSlice.reducer;