﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Entities;

namespace Infrastructure.Persistence
{
    public class DbSeeder
    {
        public static void Seed(AppDbContext context)
        {
            if (!context.Flights.Any())
            {
                context.Flights.AddRange(new[]
                {
                new Flight { FlightNumber = "LY001", Destination = "New York", DepartureTime = DateTime.UtcNow.AddHours(1), Gate = "A1" },
                new Flight { FlightNumber = "BA256", Destination = "London", DepartureTime = DateTime.UtcNow.AddMinutes(45), Gate = "B2" },
                new Flight { FlightNumber = "AF789", Destination = "Paris", DepartureTime = DateTime.UtcNow.AddMinutes(-10), Gate = "C3" },
            });

                context.SaveChanges();
            }
        }
    }
}
