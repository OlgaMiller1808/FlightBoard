import { useEffect } from 'react';
import { connection } from './connection';
import { useQueryClient } from '@tanstack/react-query';

export const SignalRListener = () => {
  const queryClient = useQueryClient();

  useEffect(() => {
    let isMounted = true;

    const startConnection = async () => {
      try {
        if (connection.state === 'Disconnected') {
          await connection.start();
          console.log('✅ SignalR connected');
        }
      } catch (err) {
        console.error('SignalR connection error:', err);
      }
    };

    startConnection();

    const invalidate = () => {
      if (isMounted) {
        queryClient.invalidateQueries({ queryKey: ['flights'] });
      }
    };

    connection.on('FlightCreated', invalidate);
    connection.on('FlightUpdated', invalidate);
    connection.on('FlightDeleted', invalidate);

    return () => {
      isMounted = false;
      connection.off('FlightCreated', invalidate);
      connection.off('FlightUpdated', invalidate);
      connection.off('FlightDeleted', invalidate);
      connection.stop(); 
    };
  }, [queryClient]);

  return null;
};
